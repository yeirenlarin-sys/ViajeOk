package com.viajeok.app

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

class Overlay(private val ctx: Context) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private var view: TextView? = null
    private val hide = Runnable { remove() }

    fun show(r: Result) {
        val (bg, title) = when (r.verdict) {
            Verdict.GOOD -> Color.parseColor("#2E7D32") to "🟢 TE CONVIENE"
            Verdict.MEDIUM -> Color.parseColor("#F9A825") to "🟡 REGULAR"
            Verdict.BAD -> Color.parseColor("#C62828") to "🔴 NO CONVIENE"
        }
        val text = "$title\n$%.2f por ${r.minutes} min (mínimo $%.2f)".format(r.price, r.minPrice)
        showRaw(bg, text)
    }

    fun showRaw(bg: Int, text: String) {
        val isService = ctx is AccessibilityService
        if (!isService && !Settings.canDrawOverlays(ctx)) return
        handler.removeCallbacks(hide)
        val tv = view ?: TextView(ctx).also {
            it.setTextColor(Color.WHITE)
            it.textSize = 18f
            it.typeface = Typeface.DEFAULT_BOLD
            it.gravity = Gravity.CENTER
            it.setPadding(40, 28, 40, 28)
            val type = if (isService) WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
                       else WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP
            lp.y = 120
            wm.addView(it, lp)
            view = it
        }
        tv.setBackgroundColor(bg)
        tv.text = text
        handler.postDelayed(hide, 8000)
    }

    fun remove() {
        view?.let { runCatching { wm.removeView(it) } }
        view = null
    }
}
