package com.viajeok.app

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var diag: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = getSharedPreferences("cfg", MODE_PRIVATE)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 64, 48, 48) }

        fun field(label: String, key: String, def: Float): EditText {
            box.addView(TextView(this).apply { text = label })
            return EditText(this).apply {
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
                setText(p.getFloat(key, def).toString())
                box.addView(this)
            }
        }

        box.addView(TextView(this).apply { text = "Viaje OK – precio mínimo por tiempo"; textSize = 20f })
        status = TextView(this).apply { textSize = 16f; setPadding(0, 24, 0, 24) }
        box.addView(status)

        box.addView(Button(this).apply {
            text = "Probar aviso (sin inDrive)"
            setOnClickListener {
                Overlay(applicationContext).show(Evaluator.evaluate(applicationContext, 3.0, 17))
            }
        })
        box.addView(Button(this).apply {
            text = "1) Permiso: mostrar sobre otras apps"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        })
        box.addView(Button(this).apply {
            text = "2) Activar servicio de accesibilidad"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })

        val f10 = field("Hasta 10 min ($)", "p10", 2f)
        val f20 = field("Hasta 20 min ($)", "p20", 3f)
        val f30 = field("Hasta 30 min ($)", "p30", 4f)
        val fx = field("Extra por cada minuto sobre 30 ($)", "extra", 0.15f)
        val cb = CheckBox(this).apply { text = "Sumar tiempo de recogida"; isChecked = p.getBoolean("pickup", true) }
        box.addView(cb)
        box.addView(Button(this).apply {
            text = "Guardar"
            setOnClickListener {
                p.edit()
                    .putFloat("p10", f10.text.toString().toFloatOrNull() ?: 2f)
                    .putFloat("p20", f20.text.toString().toFloatOrNull() ?: 3f)
                    .putFloat("p30", f30.text.toString().toFloatOrNull() ?: 4f)
                    .putFloat("extra", fx.text.toString().toFloatOrNull() ?: 0.15f)
                    .putBoolean("pickup", cb.isChecked).apply()
                Toast.makeText(context, "Guardado", Toast.LENGTH_SHORT).show()
            }
        })

        box.addView(TextView(this).apply { text = "Diagnóstico"; textSize = 18f; setPadding(0, 40, 0, 8) })
        box.addView(Button(this).apply {
            text = "Actualizar diagnóstico"
            setOnClickListener { refresh() }
        })
        box.addView(Button(this).apply {
            text = "Copiar diagnóstico"
            setOnClickListener {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("diagnostico", diag.text))
                Toast.makeText(context, "Copiado", Toast.LENGTH_SHORT).show()
            }
        })
        diag = TextView(this).apply { setTextIsSelectable(true); textSize = 13f }
        box.addView(diag)

        setContentView(ScrollView(this).apply { addView(box) })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val p = getSharedPreferences("cfg", MODE_PRIVATE)
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        val acc = enabled.contains("$packageName/")
        val ov = Settings.canDrawOverlays(this)
        status.text = "Accesibilidad: " + (if (acc) "✅ activa" else "❌ apagada") +
            "\nMostrar sobre otras apps: " + (if (ov) "✅ activo" else "❌ apagado")
        val t = p.getLong("dbg_time", 0L)
        val hora = if (t == 0L) "nunca" else SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(t))
        diag.text = "Apps vistas por el servicio: " + (p.getString("pkgs", null) ?: "(ninguna)") +
            "\n\nÚltima lectura de inDrive: " + hora +
            "\n\nÚltimo resultado: " + (p.getString("last_result", null) ?: "(ninguno)") +
            "\n\nTexto leído:\n" + (p.getString("dbg", null) ?: "(sin datos: nunca se detectó inDrive)")
    }
}
