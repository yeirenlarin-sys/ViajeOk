package com.viajeok.app

import android.accessibilityservice.AccessibilityService
import android.content.SharedPreferences
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Solo LEE la pantalla de inDrive. No acepta, no toca, no envía nada. */
class InDriveService : AccessibilityService() {
    private lateinit var overlay: Overlay
    private var lastKey = ""
    private var lastShown = 0L
    private var lastDbg = ""
    private val seenPkgs = LinkedHashSet<String>()

    override fun onServiceConnected() {
        overlay = Overlay(this)
    }

    private fun isInDrive(pkg: String?): Boolean {
        val s = pkg?.lowercase() ?: return false
        return s.contains("indriver") || s.contains("indrive")
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName) return
        val p = getSharedPreferences("cfg", MODE_PRIVATE)

        if (seenPkgs.add(pkg)) {
            if (seenPkgs.size > 12) seenPkgs.remove(seenPkgs.first())
            p.edit().putString("pkgs", seenPkgs.joinToString(", ")).apply()
        }
        if (!isInDrive(pkg)) return

        // Lee TODAS las ventanas de inDrive (la oferta puede ser una ventana flotante aparte).
        val groups = mutableListOf<List<String>>()
        try {
            for (w in windows) {
                val r = w.root ?: continue
                if (isInDrive(r.packageName?.toString())) {
                    val t = mutableListOf<String>()
                    collect(r, t, 0)
                    if (t.isNotEmpty()) groups.add(t)
                }
            }
        } catch (ex: Exception) {
        }
        if (groups.isEmpty()) {
            val t = mutableListOf<String>()
            e.source?.let { collect(it, t, 0) }
            if (t.isEmpty()) rootInActiveWindow?.let { collect(it, t, 0) }
            if (t.isNotEmpty()) groups.add(t)
        }
        if (groups.isEmpty()) return

        val all = groups.joinToString("\n--- ventana ---\n") { it.joinToString(" | ") }.take(2500)
        if (all != lastDbg) {
            lastDbg = all
            p.edit().putString("dbg", all).putLong("dbg_time", System.currentTimeMillis()).apply()
        }

        for (g in groups) {
            val r = tryEval(g, p) ?: continue
            val key = "${r.price}-${r.minutes}"
            val now = System.currentTimeMillis()
            if (key == lastKey && now - lastShown < 15000) return
            lastKey = key
            lastShown = now
            p.edit().putString("last_result", "${r.verdict}: precio ${r.price}, ${r.minutes} min, mínimo ${r.minPrice}").apply()
            overlay.show(r)
            return
        }
    }

    private fun parsePrice(s: String): Double? {
        val m = Regex("""(?:US\s?)?\$\s?(\d{1,3}(?:[.,]\d{1,2})?)""").find(s)
            ?: Regex("""(\d{1,3}(?:[.,]\d{1,2})?)\s?\$""").find(s)
            ?: return null
        return m.groupValues[1].replace(',', '.').toDoubleOrNull()
    }

    private fun tryEval(texts: List<String>, p: SharedPreferences): Result? {
        val joined = texts.joinToString(" | ")
        val price = parsePrice(joined) ?: return null
        val mins = Regex("""(\d+)\s*min""", RegexOption.IGNORE_CASE)
            .findAll(joined).map { it.groupValues[1].toInt() }.toList()
        if (mins.isEmpty()) return null
        val countPickup = p.getBoolean("pickup", true)
        val minutes = if (countPickup) mins.take(2).sum() else (mins.getOrNull(1) ?: mins[0])
        return Evaluator.evaluate(this, price, minutes)
    }

    private fun collect(n: AccessibilityNodeInfo?, out: MutableList<String>, depth: Int) {
        if (n == null || depth > 40) return
        n.text?.toString()?.takeIf { it.isNotBlank() }?.let { out.add(it) }
        n.contentDescription?.toString()?.takeIf { it.isNotBlank() }?.let { out.add(it) }
        for (i in 0 until n.childCount) collect(n.getChild(i), out, depth + 1)
    }

    override fun onInterrupt() {
        if (::overlay.isInitialized) overlay.remove()
    }
}
