package com.viajeok.app

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Solo LEE la pantalla de inDrive. No acepta, no toca, no envía nada. */
class InDriveService : AccessibilityService() {
    private lateinit var overlay: Overlay
    private var lastKey = ""

    override fun onServiceConnected() { overlay = Overlay(this) }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        val pkg = e?.packageName?.toString()?.lowercase() ?: return
        if (!pkg.contains("indriver") && !pkg.contains("indrive")) return
        val root = rootInActiveWindow ?: return
        val texts = mutableListOf<String>()
        collect(root, texts)
        val joined = texts.joinToString(" | ")

        val price = Regex("""\$\s?(\d+(?:[.,]\d{1,2})?)""").find(joined)
            ?.groupValues?.get(1)?.replace(',', '.')?.toDoubleOrNull() ?: return
        // Primer "N min" = recogida, segundo = viaje (supuesto; ajustable si inDrive muestra otro orden)
        val mins = Regex("""(\d+)\s*min""").findAll(joined).map { it.groupValues[1].toInt() }.toList()
        if (mins.isEmpty()) return
        val countPickup = getSharedPreferences("cfg", MODE_PRIVATE).getBoolean("pickup", true)
        val minutes = if (countPickup) mins.take(2).sum() else (mins.getOrNull(1) ?: mins[0])

        val key = "$price-$minutes"
        if (key == lastKey) return
        lastKey = key
        overlay.show(Evaluator.evaluate(this, price, minutes))
    }

    private fun collect(n: AccessibilityNodeInfo?, out: MutableList<String>) {
        if (n == null) return
        n.text?.toString()?.takeIf { it.isNotBlank() }?.let { out.add(it) }
        for (i in 0 until n.childCount) collect(n.getChild(i), out)
    }

    override fun onInterrupt() { overlay.remove() }
}
