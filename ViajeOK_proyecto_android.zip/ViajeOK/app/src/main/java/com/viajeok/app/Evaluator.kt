package com.viajeok.app

import android.content.Context

enum class Verdict { GOOD, MEDIUM, BAD }

data class Result(val verdict: Verdict, val minPrice: Double, val minutes: Int, val price: Double)

object Evaluator {
    // Precio mínimo según tiempo. Tramos: hasta 10 min, hasta 20, hasta 30.
    // Los minutos entre tramos (11-14, 21-24) caen en el tramo siguiente, o sea, exige más.
    fun minPriceFor(ctx: Context, minutes: Int): Double {
        val p = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)
        val p10 = p.getFloat("p10", 2f).toDouble()
        val p20 = p.getFloat("p20", 3f).toDouble()
        val p30 = p.getFloat("p30", 4f).toDouble()
        val extra = p.getFloat("extra", 0.15f).toDouble() // por cada minuto sobre 30
        return when {
            minutes <= 10 -> p10
            minutes <= 20 -> p20
            minutes <= 30 -> p30
            else -> p30 + extra * (minutes - 30)
        }
    }

    fun evaluate(ctx: Context, price: Double, minutes: Int): Result {
        val min = minPriceFor(ctx, minutes)
        val v = when {
            price >= min -> Verdict.GOOD
            price >= min * 0.85 -> Verdict.MEDIUM
            else -> Verdict.BAD
        }
        return Result(v, min, minutes, price)
    }
}
