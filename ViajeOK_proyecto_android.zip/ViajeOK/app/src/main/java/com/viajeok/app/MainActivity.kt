package com.viajeok.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = getSharedPreferences("cfg", MODE_PRIVATE)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 64, 48, 48) }

        fun field(label: String, key: String, def: Float): EditText {
            box.addView(TextView(this).apply { text = label })
            return EditText(this).apply {
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
                setText(p.getFloat(key, def).toString())
                box.addView(this)
            }
        }
        box.addView(TextView(this).apply { text = "Viaje OK – precio mínimo por tiempo"; textSize = 20f })
        val f10 = field("Hasta 10 min ($)", "p10", 2f)
        val f20 = field("Hasta 20 min ($)", "p20", 3f)
        val f30 = field("Hasta 30 min ($)", "p30", 4f)
        val fx = field("Extra por cada minuto sobre 30 ($)", "extra", 0.15f)
        val cb = CheckBox(this).apply { text = "Sumar tiempo de recogida"; isChecked = p.getBoolean("pickup", true) }
        box.addView(cb)

        box.addView(Button(this).apply {
            text = "Guardar"
            setOnClickListener {
                p.edit()
                    .putFloat("p10", f10.text.toString().toFloatOrNull() ?: 2f)
                    .putFloat("p20", f20.text.toString().toFloatOrNull() ?: 3f)
                    .putFloat("p30", f30.text.toString().toFloatOrNull() ?: 4f)
                    .putFloat("extra", fx.text.toString().toFloatOrNull() ?: 0.15f)
                    .putBoolean("pickup", cb.isChecked).apply()
                Toast.makeText(context, "Guardado", Toast.LENGTH_SHORT).show()
            }
        })
        box.addView(Button(this).apply {
            text = "1) Permiso: mostrar sobre otras apps"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        })
        box.addView(Button(this).apply {
            text = "2) Activar servicio de accesibilidad"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        setContentView(ScrollView(this).apply { addView(box) })
    }
}
